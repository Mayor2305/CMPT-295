/*
Part 1 - Mystery Caches
*/

#include <stdlib.h>
#include <stdio.h>

#include "support/mystery-cache.h"

/*
 * NOTE: When using access_cache() you do not need to provide a "real" memory
 * addresses. You can use any convenient integer value as a memory address,
 * you should not be able to cause a segmentation fault by providing a memory
 * address out of your programs address space as the argument to access_cache.
 */

/*
   Returns the size (in B) of each block in the cache.
*/
int get_block_size(void) {

	addr_t temp = 0xDEADBEEF;

	bool_t foo = TRUE;

	flush_cache();

	access_cache(temp);

	int size = 0;
	for(addr_t i = temp; foo == TRUE; i += 0x00000001)
	{
		foo = access_cache(i);

		if(foo == TRUE)
		size++;
	}

	foo = TRUE;

	for(addr_t i = temp - 0x00000001; foo == TRUE; i-= 0x00000001)
	{
		foo = access_cache(i);
		if(foo == TRUE)
		size++;
	}

  return size;
}

/*
   Returns the size (in B) of the cache.
*/
int get_cache_size(int block_size) {

	int size = 0;
	bool_t foo = TRUE;

	for(;foo == TRUE;){

		flush_cache();
		access_cache(0 * block_size);

		for(addr_t j = 1; j <= size; j += 0x00000001)
		{
			access_cache(j * block_size);
		}

		foo = access_cache(0 * block_size);

		if(foo == TRUE){
			size ++;
		}
	}

	return size * block_size;

}

/*
   Returns the associativity of the cache.
*/
int get_cache_assoc(int cache_size) {
  /* YOUR CODE GOES HERE */
	int size = 0;
	bool_t foo = TRUE;

	for(;foo == TRUE;){

		flush_cache();
		access_cache(0);

		for(addr_t j = 1; j <= size; j += 0x00000001)
		{
			access_cache(j * cache_size);
		}

		foo = access_cache(0);

		if(foo == TRUE)
			size ++;
	}

	return size ;
}

int main(void) {
  int size;
  int assoc;
  int block_size;

  cache_init(0, 0);

  block_size = get_block_size();
  size = get_cache_size(block_size);
  assoc = get_cache_assoc(size);

  printf("Cache block size: %d bytes\n", block_size);
  printf("Cache size: %d bytes\n", size);
  printf("Cache associativity: %d\n", assoc);

  return EXIT_SUCCESS;
}
